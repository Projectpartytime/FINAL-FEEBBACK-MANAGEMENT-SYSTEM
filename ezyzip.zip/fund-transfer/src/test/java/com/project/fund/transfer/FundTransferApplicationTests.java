package com.project.fund.transfer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FundTransferApplicationTests {

	@Test
	void contextLoads() {
	}

}
