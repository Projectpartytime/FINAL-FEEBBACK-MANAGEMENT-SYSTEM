package com.project.fund.transfer.service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.fund.transfer.dao.FundTransferRepository;
import com.project.fund.transfer.dto.Account;
import com.project.fund.transfer.service.FundService;

@Service
public class FundServiceImpl implements FundService {

	@Autowired
	private FundTransferRepository repository;

	@Override
	public Account makeFundTransfer(Account account) throws Exception {
		Optional<Account> accountFromDb = repository.findById(account.getAccountId());
		if (accountFromDb.isPresent()) {
			Account newAccount = accountFromDb.get();
			newAccount.setPaymentAmount(account.getPaymentAmount());
			newAccount.setTransactionId(Math.random());
			newAccount.setPaymentStatus("Success");
			newAccount.setCurrentBalance(newAccount.getCurrentBalance() + account.getPaymentAmount());
			newAccount = repository.save(newAccount);

			return newAccount;
		} else {
			if(account.getCurrentBalance() == 0) {
				account.setCurrentBalance(account.getPaymentAmount());
			}
			account.setTransactionId(Math.random());
			account.setPaymentStatus("Success");
			return repository.save(account);
		}
	}

	@Override
	public Account getFundByAccountId(Long accountId) throws Exception {
		Optional<Account> account = repository.findById(accountId);

		if (account.isPresent()) {
			return account.get();
		} else {
			throw new Exception("No account record exist for given id");
		}
	}

}
