package com.project.fund.transfer.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import lombok.Data;

@Data
@Entity
@Table(name = "account")
public class Account implements Serializable {

	private static final long serialVersionUID = 342119033990672047L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long accountId;

	@Column(name = "account_holder_name", nullable = false)
	private String accountHolderName;

	@NotNull(message = "Please add initial balance")
	@NotEmpty(message = "Please add initial balance")
	@Column(name = "current_balance", nullable = true)
	private int currentBalance;

	@Column(name = "payment_amount", nullable = true)
	private int paymentAmount;

	@Column(name = "transaction_id", nullable = true)
	private Double TransactionId;

	@Column(name = "payment_status", nullable = true)
	private String paymentStatus;

}
