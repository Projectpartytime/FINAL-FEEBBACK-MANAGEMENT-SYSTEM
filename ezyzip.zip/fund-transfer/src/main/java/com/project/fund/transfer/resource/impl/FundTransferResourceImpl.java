package com.project.fund.transfer.resource.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.project.fund.transfer.dto.Account;
import com.project.fund.transfer.resource.FundTransferResource;
import com.project.fund.transfer.service.FundService;

@Component
public class FundTransferResourceImpl implements FundTransferResource {

	@Autowired
	private FundService service;

	@Override
	public ResponseEntity<Object> createOrUpdateFundTransfer(Account payment) {
		try {
			Account updated = service.makeFundTransfer(payment);
			return new ResponseEntity<Object>(updated, new HttpHeaders(), HttpStatus.OK);
		} catch (Exception ex) {
			return new ResponseEntity<Object>(ex.getMessage(), new HttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public ResponseEntity<Object> getFundByAccountId(Long accountId) {
		try {
			Account entity = service.getFundByAccountId(accountId);
			return new ResponseEntity<Object>(entity, new HttpHeaders(), HttpStatus.OK);
		} catch (Exception ex) {
			return new ResponseEntity<Object>(ex.getMessage(), new HttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
