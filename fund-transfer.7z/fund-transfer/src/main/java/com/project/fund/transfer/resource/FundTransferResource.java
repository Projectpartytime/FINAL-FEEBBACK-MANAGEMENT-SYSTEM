package com.project.fund.transfer.resource;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.fund.transfer.dto.Account;

@RestController
@RequestMapping("/api/v1")
public interface FundTransferResource {

	@PostMapping("/fund/transfer")
	ResponseEntity<Object> createOrUpdateFundTransfer(@RequestBody Account payment);

	@GetMapping("/fund/{accountId}")
	ResponseEntity<Object> getFundByAccountId(@PathVariable(value = "accountId") Long accountId);

}
