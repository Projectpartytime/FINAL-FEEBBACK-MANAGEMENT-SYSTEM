package com.project.fund.transfer.service;

import com.project.fund.transfer.dto.Account;

public interface FundService {

	Account makeFundTransfer(Account account) throws Exception;

	Account getFundByAccountId(Long accountId) throws Exception;
}
