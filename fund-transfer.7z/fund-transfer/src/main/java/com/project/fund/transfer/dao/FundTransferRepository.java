package com.project.fund.transfer.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.project.fund.transfer.dto.Account;

@Repository
public interface FundTransferRepository extends JpaRepository<Account, Long>{

}
