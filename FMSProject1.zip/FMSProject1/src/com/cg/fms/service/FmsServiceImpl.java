package com.cg.fms.service;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

import com.cg.fms.bean.CourseBean;
import com.cg.fms.bean.EmployeeBean;
import com.cg.fms.bean.FeedbackBean;
import com.cg.fms.bean.TrainingBean;
import com.cg.fms.dao.FmsDaoImpl;
import com.cg.fms.dao.IFmsDao;
import com.cg.fms.exception.FeedbackException;

public class FmsServiceImpl implements IFmsService {

	IFmsDao fmsDao = new FmsDaoImpl();
	@Override
	public int insertFeedback(FeedbackBean feedback) throws FeedbackException {
		return fmsDao.insertFeedback(feedback);
	}
	@Override
	public List<EmployeeBean> getEmployeeId(String skill)throws FeedbackException {
		return fmsDao.getEmployeeId(skill);
	}
	@Override
	public long insertCourseDetails(CourseBean cbean) throws FeedbackException {
		// TODO Auto-generated method stub
		return fmsDao.insertCourseDetails(cbean);
	}
	@Override
	public  List<FeedbackBean> getFeedbackByTrainingCode(long trainingCode)
			throws FeedbackException {
		// TODO Auto-generated method stub
		return fmsDao.getFeedbackByTrainingCode(trainingCode);
	}
	@Override
	public  List<FeedbackBean> getFeedbackByParticipantId(long participantId)
			throws FeedbackException {
		// TODO Auto-generated method stub
		return fmsDao.getFeedbackByParticipantId(participantId);
	}
	@Override
	public int insertDetails(TrainingBean training) throws FeedbackException {
		// TODO Auto-generated method stub
		return fmsDao.insertDetails(training);
	}
	@Override
	public List<CourseBean> getCourseDetails() throws FeedbackException {
		
		return fmsDao.getCourseDetails();
	}
	@Override
	public int updateCourseDetails(CourseBean cbean) throws FeedbackException {
		
		return fmsDao.updateCourseDetails(cbean);
	}
	@Override
	public int deleteCourseDetails(long cid) throws FeedbackException {
		
		return fmsDao.deleteCourseDetails(cid);
	}
	@Override
	public int insertParticipantEnrollmentDetails(long trainingId,
			long participantId) throws FeedbackException {
		
		return fmsDao.insertParticipantEnrollmentDetails(trainingId, participantId);
	}
	
	/*****************checking whether detail is already exits or not********************/
	public boolean validateFeedback(long trainingId,long participantId) throws FeedbackException
	{
		
		Set<Entry<Long, Long>> setIt=fmsDao.validateFeedback();
		Iterator<Entry<Long, Long>> proIt=setIt.iterator();
		int c=0;
		while(proIt.hasNext())
		{
			
			Entry<Long, Long> proEntry =proIt.next();
			if((proEntry.getKey()==trainingId) && (proEntry.getValue()==participantId))
			{
				c++;
			}
		}
		if(c==0)
		{
			return true;
		}
		return false;
	}
	/*****************checking whether participant is already enrolled or not********************/
	public boolean validateParticipantEnroll(long trainingId,long participantId) throws FeedbackException
	{
		
		Set<Entry<Long, Long>> setIt=fmsDao.validateParticipantEnroll();
		Iterator<Entry<Long, Long>> proIt=setIt.iterator();
		int c=0;
		while(proIt.hasNext())
		{
			
			Entry<Long, Long> proEntry =proIt.next();
			if((proEntry.getKey()==trainingId) && (proEntry.getValue()==participantId))
			{
				c++;
			}
		}
		if(c==0)
		{
			return true;
		}
		return false;
	}
	/*****************checking whether CourseId is already exists or not********************/
	@Override
	public boolean validateCourseIds(long courseId) throws FeedbackException {
		List<Long> courseCode = fmsDao.validateGetCourseId();
		for(Long id:courseCode)
		{
			if(id==courseId)
			{
				return true;
			}
		}
		return false;
	}
	/*****************checking whether FacultyId is already exists or not********************/
	@Override
	public boolean validateFacultyIds(long facultyId) throws FeedbackException {
		List<Long> facultyCode = fmsDao.validateGetFacultyId();
		for(Long id:facultyCode)
		{
			if(id==facultyId)
			{
				return true;
			}
		}
		return false;
	}
	/*****************checking duration of Course********************/
	@Override
	public long validateDurationOfCourse(long courseId)
			throws FeedbackException 
	{
		return fmsDao.validateGetDurationOfCourse(courseId);

	}
	/*****************checking whether trainingId is already exists or not********************/
	
	@Override
	public boolean validateTrainingIds(long trainingId)
			throws FeedbackException {
		List<Long> trainingCode = fmsDao.validateGetAllTrainingIds();
		for(Long id:trainingCode)
		{
			if(id==trainingId)
			{
				return true;
			}
		}
		return false;
	}
	@Override
	public EmployeeBean validateEmpId(long empId) throws FeedbackException 
	{
		EmployeeBean ebean=fmsDao.retrievePassword(empId);
		return ebean;
	}
	}
	

