package com.cg.fms.service;

import java.util.List;

import com.cg.fms.bean.CourseBean;
import com.cg.fms.bean.EmployeeBean;
import com.cg.fms.bean.FeedbackBean;
import com.cg.fms.bean.TrainingBean;
import com.cg.fms.exception.FeedbackException;

public interface IFmsService {
	/**login*/
	EmployeeBean validateEmpId(long empId)throws FeedbackException;

	/*Admin Methods*/
	List<EmployeeBean> getEmployeeId(String skill)throws FeedbackException;
	public long insertCourseDetails(CourseBean cbean)throws FeedbackException;
	public  List<FeedbackBean> getFeedbackByTrainingCode(long trainingCode)throws FeedbackException;
	public List<FeedbackBean> getFeedbackByParticipantId(long participantId)throws FeedbackException;
	List<CourseBean> getCourseDetails()throws FeedbackException;
	public int updateCourseDetails(CourseBean cbean)throws FeedbackException;
	public int deleteCourseDetails(long cid)throws FeedbackException;
	/**Admin Validation**/
	boolean validateCourseIds(long courseId)throws FeedbackException;
	
	/*Participants Methods*/
	int insertFeedback(FeedbackBean feedback) throws FeedbackException;
	
		/*******validation of participants******/
	public boolean validateFeedback(long trainingId,long participantId)throws FeedbackException;
	boolean validateTrainingIds(long trainingId)throws FeedbackException;
	/*Coordinator*/
	public int insertDetails(TrainingBean training) throws FeedbackException;
	public int insertParticipantEnrollmentDetails(long trainingId, long participantId) throws FeedbackException;
	
	/**coordinator Validation**/
	boolean validateParticipantEnroll(long trainingId,long participantId) throws FeedbackException;
	boolean validateFacultyIds(long facultyId)throws FeedbackException;
	long validateDurationOfCourse(long courseId) throws FeedbackException;
	
}
