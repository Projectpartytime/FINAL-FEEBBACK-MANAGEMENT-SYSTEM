package com.cg.fms.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.Map.Entry;



import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.fms.bean.CourseBean;
import com.cg.fms.bean.EmployeeBean;
import com.cg.fms.bean.FeedbackBean;
import com.cg.fms.bean.TrainingBean;
import com.cg.fms.exception.FeedbackException;
import com.cg.fms.util.DBUtil;


public class FmsDaoImpl implements IFmsDao {

	Connection conn;
	PreparedStatement pst;
	ResultSet rs;
	Statement st;
	Logger log=null;


	public FmsDaoImpl() {
		PropertyConfigurator.configure("resourses/log4j.properties");
		log=Logger.getLogger("FmsDaoImpl.class");
		log.info("Application Started");
	}

	@Override
	public int insertFeedback(FeedbackBean feedback) throws FeedbackException 
	{
		log.info("Inserting Feeback Report Details for \n"
				+ "Training ID: "+feedback.getTrainingCode()+"\nParticipant ID: "+feedback.getParticipantId());
		conn = DBUtil.getConnection();
		int dataInserted;
		try 
		{
			if(feedback.getPresentComm()>=1 && feedback.getPresentComm()<=5 &&
					feedback.getClarifyDoubt()>=1 && feedback.getClarifyDoubt()<=5 &&
					feedback.getTimeManage()>=1 && feedback.getTimeManage()<=5 &&
					feedback.getHandOut()>=1 && feedback.getHandOut()<=5 &&
					feedback.getHardSoftNet()>=1 && feedback.getHardSoftNet()<=5)
			{
			pst = conn.prepareStatement(QueryMapper.INSERT_PARTICIPANT_FB);
			pst.setLong(1, feedback.getTrainingCode());
			pst.setLong(2, feedback.getParticipantId());
			pst.setInt(3, feedback.getPresentComm());
			pst.setInt(4, feedback.getClarifyDoubt());
			pst.setInt(5, feedback.getTimeManage());
			pst.setInt(6, feedback.getHandOut());
			pst.setInt(7, feedback.getHardSoftNet());
			pst.setString(8, feedback.getComments());
			pst.setString(9, feedback.getSuggestions());

			dataInserted = pst.executeUpdate();
			}
			else
			{
				log.error("Insertion failed..Please enter valid feedback value");
				throw new FeedbackException("Insertion failed..Please enter valid feedback value ");
			}
		} 
		catch (SQLException e) 
		{
			log.error("Error occured : Problem in inserting feedback Details : Something went wrong ");
			throw new FeedbackException("Problem in inserting feedback Details ");
		}

		return dataInserted;
	}

	@Override
	public List<EmployeeBean> getEmployeeId(String skill)throws FeedbackException 
	{
		log.info("Get Employee ID based on Skill :"+skill );

		List<EmployeeBean> empList= new ArrayList<EmployeeBean>();
		EmployeeBean ebean;
		try 
		{

			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(QueryMapper.Faculty_Skill_Maintenance);
			pst.setString(1,skill);
			rs=pst.executeQuery();

			while(rs.next())
			{
				ebean=new EmployeeBean();
				ebean.setEmployeeId(rs.getLong("EMPLOYEE_ID"));
				ebean.setEmployeeName(rs.getString("EMPLOYEE_NAME"));
				ebean.setRole(rs.getString("ROLE"));
				ebean.setSkillSet(rs.getString("SKILL_SET"));
				empList.add(ebean);
			}
		}
		catch (Exception e)
		{
			log.error("Error occured : Employee Details cannot be retrieved : Something went wrong ");
			throw new FeedbackException("Problem while retriving Employee ID from database");

		}
		return empList;
	}

	@Override
	public long insertCourseDetails(CourseBean cbean) throws FeedbackException 
	{
		cbean.setCourseId(generateCourseId());
		log.info("Insert Course Details :\n"
				+ "Course ID : "+cbean.getCourseId()+""
				+ "\nCourse Name :"+cbean.getCourseName()+"\n"
				+ ""+cbean.getNoOfDays() );
		try 
		{
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(QueryMapper.Course_Maintenance);
			pst.setLong(1,cbean.getCourseId());
			pst.setString(2,cbean.getCourseName());
			pst.setLong(3,cbean.getNoOfDays());
			pst.executeUpdate();
		}
		catch (Exception e)
		{
			log.error("Error occured : Problem in Inserting CourseDetails : Something went wrong ");
			throw new FeedbackException("Problem in Inserting CourseDetails");
		}
		return cbean.getCourseId();
	}
	/***************getFeedbackByTrainingCode()*******************/
	@Override
	public List<FeedbackBean> getFeedbackByTrainingCode(long trainingCode)
			throws FeedbackException 
			{
		log.info("Retrieving feedback Details Based on Training ID :"+trainingCode);
		FeedbackBean fbean=null;	
		List<FeedbackBean> feedbackList= new ArrayList<FeedbackBean>();
		try 
		{
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(QueryMapper.VIEW_FEEDBACK_BY_TRAININGCODE);
			pst.setLong(1, trainingCode);
			rs=pst.executeQuery();
			while(rs.next())
			{
				fbean=new FeedbackBean();
				fbean.setTrainingCode(rs.getLong("training_code"));
				fbean.setParticipantId(rs.getLong("participant_id"));
				fbean.setPresentComm(rs.getInt("fb_prs_comm"));
				fbean.setClarifyDoubt(rs.getInt("fb_clrfy_dbts"));
				fbean.setTimeManage(rs.getInt("fb_tm"));
				fbean.setHandOut(rs.getInt("fb_hand_out"));		
				fbean.setHardSoftNet(rs.getInt("fb_hw_sw_ntwrk"));
				fbean.setComments(rs.getString("comments"));
				fbean.setSuggestions(rs.getString("suggestions"));
				feedbackList.add(fbean);
			}
		}
		catch (Exception e)
		{
			log.error("Error occured : Problem in fetching Feedback based on TrainingCode ");
			throw new FeedbackException("Problem in fetching Feedback based on TrainingCode");
		} 
		return feedbackList;
			}
	/***************getFeedbackByParticipantId()*******************/
	@Override
	public List<FeedbackBean> getFeedbackByParticipantId(long participantId)
			throws FeedbackException 
			{
		log.info("Retrieving feedback Details Based on Participant ID :"+participantId);
		FeedbackBean fbean=null;	
		List<FeedbackBean> feedbackList= new ArrayList<FeedbackBean>();
		try 
		{
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(QueryMapper.VIEW_FEEDBACK_BY_PARTICIPANTCODE);
			pst.setLong(1, participantId);
			rs=pst.executeQuery();
			while(rs.next())
			{
				fbean=new FeedbackBean();
				fbean.setTrainingCode(rs.getLong("training_code"));
				fbean.setParticipantId(rs.getLong("participant_id"));
				fbean.setPresentComm(rs.getInt("fb_prs_comm"));
				fbean.setClarifyDoubt(rs.getInt("fb_clrfy_dbts"));
				fbean.setTimeManage(rs.getInt("fb_tm"));
				fbean.setHandOut(rs.getInt("fb_hand_out"));		
				fbean.setHardSoftNet(rs.getInt("fb_hw_sw_ntwrk"));
				fbean.setComments(rs.getString("comments"));
				fbean.setSuggestions(rs.getString("suggestions"));
				feedbackList.add(fbean);
			}
		}
		catch (Exception e)
		{
			log.error("Problem in fetching Feedback from Participant");
			throw new FeedbackException("Problem in fetching Feedback from Participant");

		} 
		return feedbackList;
			}
	/***************generateCourseId************************/
	private long generateCourseId() throws FeedbackException 
	{
		log.info("Generating Course ID");
		long courseId=0;
		try 
		{
			conn=DBUtil.getConnection();
			st=conn.createStatement();
			rs=st.executeQuery(QueryMapper.selectsequence);
			rs.next();
			courseId=rs.getLong(1);

		}
		catch (Exception e) 
		{
			log.error("Problem in Generating sequence");
			throw new FeedbackException("Problem in generating sequence");
		}
		log.info("Generated Course ID: "+courseId);
		return courseId;
	}
	/****************************************************************************/
	/****************************Coordinator*************************************/
	@Override
	public int insertDetails(TrainingBean training) throws FeedbackException {
		training.setTrainingCode(generateTrainingCode());
		int dataAdded=0;
		log.info("Inserting Training Details \n"
				+ "Training ID: "+training.getTrainingCode()+"\nCourse ID :"+training.getCourseCode()+
				"\nFaculty Code :"+training.getFacultyCode()+"\nStart Date: "+training.getStartDate()+
				"\nEnd Date :"+training.getEndDate());
		try
		{
			conn=DBUtil.getConnection();
			LocalDate date=training.getStartDate();
			Date sdate=Date.valueOf(date);
			pst=conn.prepareStatement(QueryMapper.TRAINING_MASTER_INSERT_QUERY);
			pst.setLong(1, training.getTrainingCode());
			pst.setLong(2, training.getCourseCode());
			pst.setLong(3, training.getFacultyCode());
			pst.setDate(4, sdate);
			pst.setDate(5, Date.valueOf(training.getEndDate()));
			dataAdded =pst.executeUpdate();
		} 
		catch (Exception e) 
		{
			log.error("Problem while Inserting into Training Master");
			throw new FeedbackException("Problem while inserting Into Training_master");
		} 
		finally
		{
			try 
			{
				pst.close();
				conn.close();
			} 
			catch (Exception e) 
			{

				throw new FeedbackException(e.getMessage());
			}
		}
		return dataAdded;
	}
	/***************generateTrainingCode************************/
	private long generateTrainingCode()  throws FeedbackException 
	{
		log.info("Generating Training Code");
		long tcode;
		String qry = "SELECT seq_training_code.NEXTVAL FROM DUAL";
		conn=DBUtil.getConnection();
		try
		{
			Statement st=conn.createStatement();
			ResultSet rst=st.executeQuery(qry);
			rst.next();
			tcode=rst.getLong(1);
		}
		catch(Exception e)
		{
			log.error("Problem in generating Purchase ID");
			throw new FeedbackException("Problem in generating Purchase Id");
		}
		log.info("Generated Training ID :: "+tcode);
		return tcode;
	}
	/****************Display Course Details********************/
	@Override
	public List<CourseBean> getCourseDetails() throws FeedbackException
	{
		log.info("Display All Course Details..");
		List<CourseBean> courses = new ArrayList<CourseBean>();
		try {
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(QueryMapper.Course_Maintenance_display);

			rs=pst.executeQuery();
			while(rs.next())
			{
				CourseBean course = new CourseBean();
				course.setCourseId(rs.getLong(1));
				course.setCourseName(rs.getString(2));
				course.setNoOfDays(rs.getLong(3));
				courses.add(course);
			}
		} 
		catch (Exception e)
		{
			log.error("ERROR IN RETRIEVING COURSEDETAILS");
			throw new FeedbackException("ERROR IN RETRIEVING COURSEDETAILS");		
		}
		return courses;
	}
	/**************updateCourseDetails******************/
	@Override
	public int updateCourseDetails(CourseBean cbean) throws FeedbackException 
	{
		log.info("Updating Course Details..");
		int row=0;
		try 
		{
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(QueryMapper.Course_Maintenance_Update);
			pst.setString(1, cbean.getCourseName());
			pst.setLong(2, cbean.getNoOfDays());
			pst.setLong(3, cbean.getCourseId());
			row = pst.executeUpdate();
			log.info("Updated Course Details are :\n"
					+ "Course ID :"+cbean.getCourseId()+"\nCourse Name :"+cbean.getCourseName()+
					"\nDuration :"+cbean.getNoOfDays());
		} 
		catch (Exception e) 
		{
			log.error("ERROR IN UPDATING COURSE DETAILS");
			throw new FeedbackException("ERROR IN UPDATING COURSE DETAILS");

		}
		return row;
	}
	/**************deleteCourseDetails******************/
	@Override
	public int deleteCourseDetails(long cid) throws FeedbackException
	{
		log.info("Deleting Course Details Based on ID "+cid);
		int row=0;
		try 
		{
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(QueryMapper.Course_Maintenance_Delete);
			pst.setLong(1, cid);
			row = pst.executeUpdate();

		} 
		catch (Exception e) 
		{
			log.error("ERROR WHILE DELETING COURSEDETAILS");
			throw new FeedbackException("ERROR WHILE DELETING COURSEDETAILS");
		}
		return row;
	}
	/**************insertParticipantEnrollmentDetails******************/
	@Override
	public int insertParticipantEnrollmentDetails(long trainingId, long participantId)
			throws FeedbackException {
		int dataAdded=0;
		log.info("Inserting Participant Enrollment Detail\n"
				+ "Training ID: "+trainingId+"\nParticipant ID: "+participantId);
		try
		{
			conn=DBUtil.getConnection();

			pst=conn.prepareStatement(QueryMapper.PARTICIPANT_ENROLLMENT_INSERT_QUERY);
			pst.setLong(1, trainingId);
			pst.setLong(2, participantId);
			dataAdded =pst.executeUpdate();
		} 
		catch (Exception e) 
		{
			log.error("Problem while Enrolling participant");
			throw new FeedbackException("Problem while Enrolling participant  ");
		} 
		finally
		{
			try 
			{
				pst.close();
				conn.close();
			} 
			catch (Exception e) 
			{
				throw new FeedbackException(e.getMessage());
			}
		}
		return dataAdded;
	}

	/**************validating whether paticipant already exits or not*********************/
	public Set<Entry<Long, Long>> validateFeedback() throws FeedbackException
	{
		log.info("Validating whether paticipant already exits or not");
		HashMap<Long,Long> enrolled= new  HashMap<Long,Long>();
		Set<Entry<Long, Long>> setIt = null;
		try 
		{
			conn=DBUtil.getConnection();
			st=conn.createStatement();
			rs=st.executeQuery(QueryMapper.VALID_FEEDBACK);
			while(rs.next())
			{
				long tCode=rs.getLong("training_code");
				long pCode=rs.getLong("participant_id");
				enrolled.put(tCode,pCode);
			}
			setIt=enrolled.entrySet();
		}
		catch (Exception e) 
		{
			log.error("Error while validating whether Participant already given feedback or not");
			throw new FeedbackException("Error while validating whether Participant already given feedback or not");
		}
		return setIt;
	}

	@Override
	public Set<Entry<Long, Long>> validateParticipantEnroll()throws FeedbackException 
	{
		HashMap<Long,Long> enrolled= new  HashMap<Long,Long>();
		Set<Entry<Long, Long>> setIt = null;
		try 
		{
			conn=DBUtil.getConnection();
			st=conn.createStatement();
			rs=st.executeQuery(QueryMapper.VALID_ENROLLMENT);
			while(rs.next())
			{
				long tCode=rs.getLong("training_code");
				long pCode=rs.getLong("participant_id");
				enrolled.put(tCode,pCode);
			}
			setIt=enrolled.entrySet();
		}
		catch (Exception e) 
		{
			log.error("Error while validating whether Participant already enrolled or not");
			throw new FeedbackException("Error while validating whether Participant already enrolled or not");
		}
		return setIt;
	}

	/**************Validating whether Course ID already exits or not
	 * *****************GetAllCourseIds*************************/
	@Override
	public List<Long> validateGetCourseId() throws FeedbackException {
		List<Long> courseIds = new ArrayList<Long>();
		try 
		{
			conn=DBUtil.getConnection();
			st=conn.createStatement();
			rs=st.executeQuery(QueryMapper.VALID_COURSE_ID);
			while(rs.next())
			{
				long cCode=rs.getLong("Course_ID");
				courseIds.add(cCode);
			}
		}
		catch (Exception e) 
		{
			log.error("Error while validating whether CourseId already Exists or not");
			throw new FeedbackException("Error while validating whether CourseId already Exists or not");
		}
		return courseIds;
	}

	/**************Validating whether Faculty ID already exits or not
	 * *****************GetAllFacultyIds*************************/
	@Override
	public List<Long> validateGetFacultyId() throws FeedbackException {
		List<Long> facultyIds = new ArrayList<Long>();
		try 
		{
			conn=DBUtil.getConnection();
			st=conn.createStatement();
			rs=st.executeQuery(QueryMapper.VALID_FACULTY_CODE);
			while(rs.next())
			{
				long fCode=rs.getLong("EMPLOYEE_ID");
				facultyIds.add(fCode);
			}
		}
		catch (Exception e) 
		{
			throw new FeedbackException("Error while validating whether Faculty Code already Exists or not");
		}
		return facultyIds;
	}
	/**************Validating whether Entered Duration is valid or not
	 * *****************GetDurationOfCourse*************************/
	@Override
	public long validateGetDurationOfCourse(long courseId) throws FeedbackException {
		conn=DBUtil.getConnection();
		long duration=0;
		try 
		{
			pst=conn.prepareStatement(QueryMapper.VALID_DURATION);
			pst.setLong(1, courseId);
			rs=pst.executeQuery();
			rs.next();
			duration=rs.getLong("no_of_days");
		}
		catch (Exception e) 
		{
			log.error("Problem while retrieveing duration of course");
			throw new FeedbackException("Problem while retrieveing duration of course");
		}
		return duration;
	}
	/**************Validating whether Training ID already exits or not
	 * *****************GetAllTrainingIds*************************/
	@Override
	public List<Long> validateGetAllTrainingIds() throws FeedbackException {
		List<Long> trainingIds = new ArrayList<Long>();
		try 
		{
			conn=DBUtil.getConnection();
			st=conn.createStatement();
			rs=st.executeQuery(QueryMapper.VALID_TRAINING_ID);
			while(rs.next())
			{
				long tCode=rs.getLong("Training_Code");
				trainingIds.add(tCode);
			}
		}
		catch (Exception e) 
		{
			log.error("Error while validating whether Training Code already Exists or not");
			throw new FeedbackException("Error while validating whether Training Code already Exists or not");
		}
		return trainingIds;
	}

	@Override
	public EmployeeBean retrievePassword(long empId) throws FeedbackException {
		log.info("Login Based on EMP ID :"+empId);	
		EmployeeBean ebean= new EmployeeBean();
		try 
		{
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(QueryMapper.login);
			pst.setLong(1, empId);
			rs=pst.executeQuery();
			rs.next();
			ebean.setEmployeeId(rs.getLong("EMPLOYEE_ID"));
			ebean.setEmployeeName(rs.getString("EMPLOYEE_NAME"));
			ebean.setPassword(rs.getString("PASSWORD"));
			ebean.setRole(rs.getString("ROLE"));
			ebean.setSkillSet(rs.getString("SKILL_SET"));
			
		}
		catch (Exception e)
		{
			log.error("Problem in retrieving employee details");
			throw new FeedbackException("Problem in retrieving employee details");

		} 
		return ebean;
	}
}
