package com.cg.fms.dao;

import java.util.List;
import java.util.Set;
import java.util.Map.Entry;

import com.cg.fms.bean.CourseBean;
import com.cg.fms.bean.EmployeeBean;
import com.cg.fms.bean.FeedbackBean;
import com.cg.fms.bean.TrainingBean;
import com.cg.fms.exception.FeedbackException;

public interface IFmsDao 
{
	/*LOGIN*/
	EmployeeBean retrievePassword(long empId)throws FeedbackException;
	
	/*Admin Methods*/
	List<EmployeeBean> getEmployeeId(String skill)throws FeedbackException;
	long insertCourseDetails(CourseBean cbean)throws FeedbackException;
	List<FeedbackBean> getFeedbackByTrainingCode(long trainingCode)throws FeedbackException;
	List<FeedbackBean> getFeedbackByParticipantId(long participantId)throws FeedbackException;
	List<CourseBean> getCourseDetails()throws FeedbackException;
	int updateCourseDetails(CourseBean cbean)throws FeedbackException;
	int deleteCourseDetails(long cid)throws FeedbackException;
	List<Long> validateGetCourseId() throws FeedbackException;
	
	/*Participants Methods*/
	int insertFeedback(FeedbackBean feedback) throws FeedbackException;
	Set<Entry<Long, Long>> validateFeedback() throws FeedbackException;
	List<Long> validateGetAllTrainingIds() throws FeedbackException;
	
	/*Coordinator*/
	int insertDetails(TrainingBean training) throws FeedbackException;
	int insertParticipantEnrollmentDetails(long trainingId, long participantId) throws FeedbackException;
	Set<Entry<Long, Long>> validateParticipantEnroll() throws FeedbackException;
	List<Long> validateGetFacultyId() throws FeedbackException;
	long validateGetDurationOfCourse(long courseId) throws FeedbackException;
	
}
