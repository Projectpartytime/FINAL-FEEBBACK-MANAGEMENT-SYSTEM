package com.cg.fms.junit;

import static org.junit.Assert.*;

import org.junit.Test;

import com.cg.fms.dao.FmsDaoImpl;
import com.cg.fms.dao.IFmsDao;
import com.cg.fms.exception.FeedbackException;

public class FmsServiceImplTest 
{
	IFmsDao fmsdao= new FmsDaoImpl();

	@Test
	public void testGetEmpId() throws FeedbackException 
	{
		assertNotNull(fmsdao.getEmployeeId("JAVA"));
	}
	@Test
	public void testGetCourseId() throws FeedbackException 
	{
		assertNotNull(fmsdao.validateGetCourseId());
	}
	@Test
	public void testInsertParticipantEnroll() throws FeedbackException {
		assertEquals(1, fmsdao.insertParticipantEnrollmentDetails(118, 42958));
	}
	@Test
	public void testgetAllTrainingId() throws FeedbackException 
	{
		assertNotNull(fmsdao.validateGetAllTrainingIds());
	}

}
