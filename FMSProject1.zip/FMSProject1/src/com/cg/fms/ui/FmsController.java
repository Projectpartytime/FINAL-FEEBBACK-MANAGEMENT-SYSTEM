package com.cg.fms.ui;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;

import com.cg.fms.bean.CourseBean;
import com.cg.fms.bean.EmployeeBean;
import com.cg.fms.bean.FeedbackBean;
import com.cg.fms.bean.TrainingBean;
import com.cg.fms.exception.FeedbackException;
import com.cg.fms.service.FmsServiceImpl;
import com.cg.fms.service.IFmsService;

public class FmsController 
{
	static Scanner sc=new Scanner(System.in);
	static IFmsService fmsSer = new FmsServiceImpl();
	static EmployeeBean ebean=null;
	public FmsController() 
	{
		displayWelcomePage();
	}
	// Welcome page function with valid login credentials

		public void displayWelcomePage() {

			boolean flag = false;
			try {
				do {
					System.out
							.println("--------------------FeedBack Management System--------------------");
					System.out.println("1. Login");
					System.out.println("2. Exit");

					int choice =sc.nextInt();

					switch (choice) {
					case 1:
						displayLogin();
						break;

					case 2:
						System.out.println("ThankYou for using Feedback Management System!");
						System.exit(0);
						break;
					default:
						System.err.println("Invalid Choice.Enter Again");
						flag = true;
						break;
					}
				} while (flag);
			} 
			catch (Exception e) 
			{
				System.err.println("Input Validation failed...");

				// displayWelcomePage();
			}
		}
		
		
		public void displayLogin() {
			boolean flag = false;
			try {
				do {
					System.out.print("Enter Employee Id: ");
					long employeeId = sc.nextLong();
					EmployeeBean ebean=fmsSer.validateEmpId(employeeId);
					if(employeeId==ebean.getEmployeeId())
					{
					System.out.print("\nEnter password: ");
					String password = sc.next();
					if(password.equalsIgnoreCase(ebean.getPassword()))
					{
					String role = ebean.getRole();

					switch (role) {
					case "Admin":
						getAdmin();
						break;

					case "Coordinator":
						getCoordinator();
						break;

					case "Participant":
						getParticipants();
						break;
					default:
						System.err.println("No user exists ");
						flag = true;
						break;
					}
					}
					else
					{
						System.err.println("Please Enter Valid Password");
					}
					}
					else
					{
						System.err.println("Please Enter Valid Employee ID..");
					}
				} while (flag);
			} 
			catch (NumberFormatException e)
			{
				System.err.println("Input Cannot contain Characters only numbers");
				displayLogin();
			} 
			catch (Exception e)
			{
				System.err.println(e.getMessage());
				displayWelcomePage();
			}
		}
		

	
	

	/*************Admin Function****************/
	private static void getAdmin() {
		while(true)
		{
			System.out.println("\nAdmin Function:");
			System.out.println("1. Faculty skill Maintenance\n"
					+ "2. Course Maintenance\n"
					+ "3. View Feedback Report\n"
					+ "4. Exit");
			int choice=sc.nextInt();
			switch(choice)
			{
			case 1:
				getFacultySkillMaintanance();
				break;
			case 2:
				getCourseMaintanance();
				break;
			case 3:
				viewFeedbackReport();
				break;
			default:
				System.exit(0);
				break;

			}
		}
	}
	/******************Faculty Skill Maintenance************/
	private static void getFacultySkillMaintanance()
	{
		System.out.println("Enter skill");
		String skill=sc.next();
		try
		{
			List<EmployeeBean> empList=fmsSer.getEmployeeId(skill);
			if(!empList.isEmpty())
			{
				System.out.println("\n\tFaculty Details");
				System.out.println("Employee_ID\t\tEmployee_Name\t\tRole\t\t\tSkills");
				for(EmployeeBean e:empList)
				{
					System.out.println(e.getEmployeeId()+"\t\t\t"+e.getEmployeeName()+"\t\t\t"+e.getRole()+"\t\t"+e.getSkillSet());
				}
				System.out.println("\n");
			}
			else
			{
				System.err.println("Skill does not Exists..");
			}
		} 
		catch (FeedbackException e)
		{
			System.err.println("Some Exception occurs while fetching data");
		}	
	}
	/****************Course Maintenance***************/
	private static void getCourseMaintanance() 
	{
		System.out.println("\nCourse Functions:");
		System.out.println("1. Add Course");
		System.out.println("2. View All Courses");
		System.out.println("3. Update Course");
		System.out.println("4. Delete Course");
		System.out.println("5. Exit from Course Maintenance");

		System.out.println("Enter choice");
		int choice=sc.nextInt();

		switch (choice) {
		case 1:
			insertCourseDetails();
			break;

		case 2:
			displayAllCourseDetails();
			break;
		case 3:
			updateCourseDetails();
			break;

		case 4:
			deleteCourseDetails();
			break;
		case 5:
			getAdmin();
			break;
		default:
			System.err.println("Invalid Choice.Enter Again");
			getCourseMaintanance();
			break;
		}
	}
	/*************Course Maintenance:INSERT**************/
	private static void insertCourseDetails()
	{
		CourseBean cbean=new CourseBean();
		System.out.println("Enter Course Name: ");
		String cname= sc.next();
		System.out.println("Enter Duration of Course: ");
		int cduration= sc.nextInt();
		cbean.setCourseName(cname);
		cbean.setNoOfDays(cduration);
		try 
		{
			Long courseId=fmsSer.insertCourseDetails(cbean);
			if(courseId!=0)
			{
				System.out.println("Data Inserted Successfully"
						+ "\nCourse ID Corresponding to "+cname+" is "+courseId+"\n\n");
			}
		} 
		catch (FeedbackException e) 
		{
			System.err.println(e.getMessage());
		}

	}
	/*************Course Maintenance:DISPLAY ALL**************/
	private static void displayAllCourseDetails()
	{

		try {
			List<CourseBean> courseList = fmsSer.getCourseDetails();
			System.out.println("\n\tAll Course Details");
			System.out.println("CourseID\tCourseName\tDuration");
			for(CourseBean course:courseList)
			{
				System.out.println(course.getCourseId()+"\t\t"+course.getCourseName()+"\t\t"+course.getNoOfDays());
			}
			System.out.println("\n");
		} 
		catch (FeedbackException e) 
		{
			System.err.println(e.getMessage());
		}
	}
	/*************Course Maintenance:UPDATE**************/
	private static void updateCourseDetails()
	{
		CourseBean cbean=new CourseBean();
		try 
		{
			System.out.println("Enter Course Id whose details need to be updated");
			Long courseId=sc.nextLong();
			if(fmsSer.validateCourseIds(courseId))
			{
				System.out.println("Enter Course Name that need to be updated");
				String courseName=sc.next();

				System.out.println("Enter No Of days that need to be updated");
				Long courseDuration=sc.nextLong();

				cbean.setCourseId(courseId);
				cbean.setCourseName(courseName);
				cbean.setNoOfDays(courseDuration);

				int dataUpdated=fmsSer.updateCourseDetails(cbean);
				if(dataUpdated==1)
				{
					System.out.println("Data Updated Successfully");
				}
				System.out.println("\n");
			}
			else
			{
				System.err.println("Course ID does not Exists..");
			}
		}
		catch (FeedbackException e)
		{
			System.err.println(e.getMessage());
		}

	}
	/*************Course Maintenance:DELETE***************/
	private static void deleteCourseDetails() {
		System.out.println("Enter Course Id whose details need to be deleted");
		Long courseId=sc.nextLong();
		try 
		{
			if(fmsSer.validateCourseIds(courseId))
			{
				int dataUpdated=fmsSer.deleteCourseDetails(courseId);
				if(dataUpdated==1)
				{
					System.out.println("Data Deleted Successfully");
				}
				System.out.println("\n");
			}
			else
			{
				System.err.println("Course ID does not Exists..");
			}
		}
		catch (FeedbackException e) 
		{
			System.err.println(e.getMessage());
		}
	} 

	/****************Admin:viewFeedbackReport*************/
	private static void viewFeedbackReport() {
		System.out.println("View Feedback Report based on:");
		System.out.println("1. Training Code"
				+ "\n2. Participant Code"
				+ "\n3. Exit");
		System.out.println("Enter your choice:");
		int choice=sc.nextInt();
		List<FeedbackBean> feedbackList = null ;
		try
		{
			switch(choice)
			{
			case 1:
				System.out.println("Enter Training code whose detail to be displayed");
				long trainingCode=sc.nextLong();
				feedbackList=fmsSer.getFeedbackByTrainingCode(trainingCode);

				break;
			case 2:
				System.out.println("Enter Participant code whose detail to be displayed");
				long participantId=sc.nextLong();
				feedbackList=fmsSer.getFeedbackByParticipantId(participantId);
				break;
			default:
				System.exit(0);
				break;

			}
			if(!feedbackList.isEmpty())
			{
				System.out.println("\n\tFeedback Report");
				System.out.println("Training Code\tParticipant Id\tSkills\tDoubts_Clarification\t"
						+ "Time management\tHand Outs\tH/W S/W Issues\tComments\tSuggestions");
				for(FeedbackBean feedback:feedbackList)
				{
					System.out.println("\t"+feedback.getTrainingCode()+"\t\t"+feedback.getParticipantId()+""
							+ "\t"+feedback.getPresentComm()+"\t"+feedback.getClarifyDoubt()+"\t\t\t"
							+ ""+feedback.getTimeManage()+"\t\t"+feedback.getHandOut()+"\t\t"
							+ ""+feedback.getHardSoftNet()+"\t\t"+feedback.getComments()+""
							+ "\t\t"+feedback.getSuggestions());
				}
				System.out.println("\n");
			}
			else
			{
				System.err.println("Please Enter Valid ID...");
			}
		}
		catch (FeedbackException e)
		{
			System.err.println(e.getMessage());
		}
	}
	/************************ADMIN DONE*******************************/


	/************************CO-ORDINATOR FUNCTIONS*******************************/

	private static void getCoordinator() {
		fmsSer=new FmsServiceImpl();
		while(true)
		{
			System.out.println("\nCo-ordinator Funtions:");
			System.out.println(" 1.Training Program maintenance "
					+"\n 2.Participant Enrollment "
					+"\n 3.View Feedback report"
					+ "\n 4.Exit");
			int trainingChoice=sc.nextInt();

			switch(trainingChoice)
			{
			case 1:
			{
				getTrainingProgramMaintenance();
				break;
			}
			case 2:
			{				
				getParticipantEnrollment();
				break;
			}
			case 3:
			{
				viewFeedbackReport();
				break;
			}

			default:
				System.exit(0);
				break;
			}
		}

	}

	/****************Co-ordinator: Training Program Maintenance*************/
	private static void getTrainingProgramMaintenance() 
	{
		try{
			TrainingBean training=new TrainingBean();
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/MM/yyyy");
			System.out.println("Enter Course code: ");
			long ccode=sc.nextLong();
			if(fmsSer.validateCourseIds(ccode))
			{
				System.out.println("Enter Faculty code: ");
				long fcode=sc.nextLong();
				if(fmsSer.validateFacultyIds(fcode))
				{
					long validDuration=fmsSer.validateDurationOfCourse(ccode);
					System.out.println("------------------------------------------------------------------------");
					System.out.println("Total Duration Of Course should be "+validDuration+" Days. "
							+ "Please Enter Details Accordingly");
					System.out.println("------------------------------------------------------------------------");
					System.out.println("Enter Start Date (DD/MM/yyyy): ");
					String sdate =sc.next();
					LocalDate startdate = LocalDate.parse(sdate, formatter);
					System.out.println("Enter End Date (DD/MM/yyyy): ");
					String edate =sc.next();
					LocalDate enddate = LocalDate.parse(edate, formatter);
					Period period=Period.between(startdate, enddate) ;
					int duration=period.getDays();

					if(validDuration==duration)
					{

						training.setCourseCode(ccode);
						training.setFacultyCode(fcode);	
						training.setStartDate(startdate);
						training.setEndDate(enddate);

						int dataAdded=0;

						dataAdded = fmsSer.insertDetails(training);
						if(dataAdded==1)
						{
							System.out.println("Data Added Successfully");
						}
						else
						{
							System.err.println("May be some exception"
									+ "while addition");
						}
					}
					else
					{

						System.err.println("The Duration of Course should be "+validDuration);
					}
				}
				else
				{
					System.err.println("Please Enter Valid Faculty Code..");
				}
			}
			else
			{
				System.err.println("Please Enter Valid CourseId..");
			}
		}
		catch (FeedbackException e) 
		{
			System.err.println(e.getMessage());
		}	
		catch(Exception e)
		{
			System.err.println("Please Enter Date in correct Format  (DD/MM/yyyy)");
		}
	}

	/****************Co-ordinator: Participant Enrollment*************/
	private static void getParticipantEnrollment() {
		System.out.println("Enter no of participants:");
		int noOfParticipants=sc.nextInt();
		try 
		{
			for(int i=0;i<noOfParticipants;i++)
			{
				System.out.println("Enter training code:");
				long trainingId=sc.nextLong();
				System.out.println("Enter partcipant code:");
				long participantId=sc.nextLong();


				if(fmsSer.validateParticipantEnroll(trainingId, participantId))
				{
					int data=fmsSer.insertParticipantEnrollmentDetails(trainingId, participantId);
					if(data==1)
					{
						System.out.println(participantId+" Participant Enrolled successfully");
					}
					else
					{
						System.out.println("May be some exception"
								+ "while Enrolling Participants");
					}
				}
				else
				{
					System.err.println("Participant already enrolled for training ID "+trainingId);
				}
			} 
		}
		catch (FeedbackException e) 
		{
			System.err.println(e.getMessage());

		}

	}

	/************************CO-ORDINATOR DONE*******************************/

	/************************PARTICIPANT FEEDBACK*******************************/
	private static void getParticipants() 
	{
		System.out.println("-------------------------------------------");
		System.out.println("Welcome Participant  \n"
				+ "Please fill the following feedback form.");
		System.out.println("-------------------------------------------");
		try {
			fmsSer=new FmsServiceImpl();
			System.out.println("Enter training code: ");
			long trainingCode = sc.nextLong();
			if(fmsSer.validateTrainingIds(trainingCode))
			{
				System.out.println("Enter participant id: ");
				long participantId = sc.nextLong();
				if(fmsSer.validateFacultyIds(participantId))
				{

				if(fmsSer.validateFeedback(trainingCode, participantId))
				{

					System.out.println("Feedback Form "
							+ "\n Rate the question according to following criteria"
							+ "\n 5-Excellent: Ideal way of doing it"
							+ "\n 4-Good: No pain areas or concern but could have been better"
							+ "\n 3-Average: There are concerns but not significant"
							+ "\n 2-Below Average: Needs improvement and is salvageable"
							+ "\n 1-Poor: This way of doing things must change");

					System.out.println("------------------------------------------------------");
					System.out.println("Please give feedback in the Range of 1 to 5 Only");
					System.out.println("------------------------------------------------------");
					System.out.println("1. Presentation and communication skills of faculty");
					int presentComm = sc.nextInt();

					System.out.println("2. Ability to clarify doubts and explain difficult points");
					int clarifyDoubt = sc.nextInt();

					System.out.println("3. Time management in completing the contents");
					int timeManage = sc.nextInt();

					System.out.println("4. Handout provided(Student Guide)");
					int handOut = sc.nextInt();

					System.out.println("5. Hardware, software and network availability");
					int hardSoftNet = sc.nextInt();

					System.out.println("6. Please give comments");
					sc.nextLine();
					String comments = sc.nextLine();

					System.out.println("7. Please give some suggestions?");
					
					String suggestions = sc.nextLine(); 


					FeedbackBean feedback = 
							new FeedbackBean(trainingCode,participantId,presentComm,clarifyDoubt,timeManage,handOut,hardSoftNet,comments,suggestions);

					try 
					{
						int dataInserted = fmsSer.insertFeedback(feedback);
						if(dataInserted == 1)
						{
							System.out.println("Details entered into feedback_master.");
						}
						else
						{
							System.err.println("Sorry could not enter details.");
						}
					} 
					catch (FeedbackException e) 
					{
						System.err.println(e.getMessage());
					}
				}
				else
				{
					System.err.println("Record already exists");	
				}
			}
				else
				{
					System.err.println("Participants ID does not Exists..");
				}
			}
			else
			{
				System.err.println("Training ID does not Exists..");
			}
		}



		catch (FeedbackException e) 
		{
			System.err.println(e.getMessage());

		}

		/************************PARTICIPANT FEEDBACK*******************************/
	}
}
