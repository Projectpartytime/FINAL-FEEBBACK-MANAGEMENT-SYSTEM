package com.cg.fms.ui;

public class Client 
{
	public static void main(String[] args) 
	{
		new FmsController();   
	}

}
