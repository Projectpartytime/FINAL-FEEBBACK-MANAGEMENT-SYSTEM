package com.cg.fms.bean;

import java.time.LocalDate;

/*Name                                      Null?    Type
----------------------------------------- -------- --------------

TRAINING_CODE                             NOT NULL NUMBER(5)
COURSE_CODE                                        NUMBER(5)
FACULTY_CODE                                       NUMBER(5)
START_DATE                                         DATE
END_DATE                                           DATE*/
public class TrainingBean
{
	private long trainingCode;
	private long courseCode;
	private long facultyCode;
	private LocalDate startDate;
	private LocalDate endDate;
	public TrainingBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public TrainingBean(long trainingCode, long courseCode, long facultyCode,
			LocalDate startDate, LocalDate endDate) {
		super();
		this.trainingCode = trainingCode;
		this.courseCode = courseCode;
		this.facultyCode = facultyCode;
		this.startDate = startDate;
		this.endDate = endDate;
	}
	public long getTrainingCode() {
		return trainingCode;
	}
	public void setTrainingCode(long trainingCode) {
		this.trainingCode = trainingCode;
	}
	public long getCourseCode() {
		return courseCode;
	}
	public void setCourseCode(long courseCode) {
		this.courseCode = courseCode;
	}
	public long getFacultyCode() {
		return facultyCode;
	}
	public void setFacultyCode(long facultyCode) {
		this.facultyCode = facultyCode;
	}
	public LocalDate getStartDate() {
		return startDate;
	}
	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}
	public LocalDate getEndDate() {
		return endDate;
	}
	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}
	@Override
	public String toString() {
		return "TrainingBean [trainingCode=" + trainingCode + ", courseCode="
				+ courseCode + ", facultyCode=" + facultyCode + ", startDate="
				+ startDate + ", endDate=" + endDate + "]";
	}
	

}
